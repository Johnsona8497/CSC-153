﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RetailMarkupCal
{
    public static class Math
    {
        //ConsoleUI.RetailMarkup.Math();
        public static double CalculateMarkup(double itemPrice, double markupPercent)
        {
            double retailPrice;
            double markupAmount;

            markupAmount = itemPrice * markupPercent;

            retailPrice = markupAmount + itemPrice;

            Console.WriteLine("The retail price for the item will be: $" + retailPrice);


            return retailPrice;
        }
        
    }
}
