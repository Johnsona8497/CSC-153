﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    /**
* 2/19/20
* CSC 153
* Anthony Johnson
*An application that lets the user enter an items wholesale cost and its markup percentage.
*/
    class Program
    {
        static void Main(string[] args)
        {

                GetMarkup.GetInputs();

                Console.ReadLine();

        }
    }
}
