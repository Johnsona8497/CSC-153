﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    public static class GetMarkup
    {
        public static void GetInputs()
        {
            string input;
            double itemPrice;
            double markupPercent;
            Console.WriteLine("Please enter the price of the item: ");
            input = Console.ReadLine();
            double.TryParse(input, out itemPrice);
            Console.WriteLine("Please enter the markup Percent in decimal form (EX 15% is = .15): ");
            input = Console.ReadLine();
            double.TryParse(input, out markupPercent);
            RetailMarkupCal.Math.CalculateMarkup(itemPrice,markupPercent);
            Console.WriteLine();

        }
    }
}
