﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Animals;

/**
* Date
* CSC 253
* William Buckwell
* This program will demostrates the use of Polymorphism
*/

namespace PolymorphDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            // This will hold the animals
            List<Animal> myAnimals = new List<Animal>();

            // Creating and adding the objects to the list at the same time
            myAnimals.Add(new Animal("Regular animal"));
            myAnimals.Add(new Dog("Fido"));
            myAnimals.Add(new Cat("Kitty"));

            // Loop through list and print the objects information
            foreach(Animal animal in myAnimals)
            {
                /**
                 * When the sound is printed it is the override method that is
                 * used. This is the advance of using Polymorphism.
                 */
                Console.WriteLine($"Species: {animal.Species}");
                Console.WriteLine(animal.MakeSound());
                Console.WriteLine();
            }

            Console.ReadLine();

            
        }
    }
}
