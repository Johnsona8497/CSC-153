﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Animals
{
    /**
     * This will be our parent Class. This class will have a species property
     * and a method. This method here is generic and will need to be overridden.
     */
    public class Animal
    {
        // Field
        private string _species;

         // Constuctor
         public Animal (string species)
        {
            _species = species;
        }

        // Species property
        public string Species
        {
            get { return _species; }
            set { _species = value; }
        }

        /*
         * Since this method will be overridden by the child class it needs
         * the keyword "virtual". This is a must!
         */
        // MakeSound method
        public virtual string MakeSound()
        {
            return "Grrrrrrrrrr";
        }
    }
}
