﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Animals
{
    /**
     * This is a child class of Animal, notice the ": Animal". However, 
     * we do not want this class to say "Grrrrrrr" so we will use and overriding 
     * method here.
     */
    public class Cat : Animal
    {

        // Field
        private string _name;

        /**
         * Notice that in this Constructor we pass a string for the
         * species to the parent class
         */
        // Constructor
        public Cat(string name) : base("Cat")
        {

        }

        // Name property
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        /**
         * This method hasthe same name as it's parent class. It also
         * uses another keyword here, "override". This will override
         * the "virtual" method in the class and use the string in 
         * this class
         */
        // MakeSound method
        public override string MakeSound()
        {
            return "Meow";
        }
    }
}
