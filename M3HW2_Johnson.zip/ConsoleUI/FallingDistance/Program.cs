﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/**
* 3/9/20
* CSC 153
* Anthony Johnson
* Falling Distance Calculator
*/

namespace FallingDistance
{
    class Program
    {
        static void Main(string[] args)
        {
            string input;
            bool exit = false;
            do
            {
                ClassLibrary.StandardMessages.Menu();
                input = Console.ReadLine();
                if (input == "1")
                {
                    GetTimeInput(input);
                }
                else if (input == "2")
                {
                    exit = true;
                }
                else
                {
                    ClassLibrary.StandardMessages.ErrorMessage();
                }
            } while (exit == false);
        }

        public static void GetTimeInput(string input)
        {
            double timeFallen;
            ClassLibrary.StandardMessages.UserTimeInput();
            input = Console.ReadLine();
            if (double.TryParse(input, out timeFallen))
            {
            }
            else
            {
                ClassLibrary.StandardMessages.ErrorMessage();
            }

            FallingDistance(timeFallen);


        }

        public static void FallingDistance(double timeFallen)
        {
            double distanceFallen;
            double gravity = 9.8;
            distanceFallen = timeFallen * timeFallen * gravity * .5;
            Console.WriteLine($"The object has fallen {distanceFallen} meters.");
        }
    }
}
