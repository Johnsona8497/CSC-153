﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassLibrary
{
    public class StandardMessages
    {
        public static void Menu()
        {
            Console.WriteLine("");
            Console.WriteLine("--------------------------------------");
            Console.WriteLine("1. Run the falling distance calulator.");
            Console.WriteLine("2. Exit the program.");
            Console.WriteLine("--------------------------------------");
            Console.Write("Input choice-->");
        }

        public static void UserTimeInput()
        {
            Console.WriteLine("Please enter the amount of time the object has fallen in seconds");
        }
        public static void ErrorMessage()
        {
            Console.WriteLine("Please enter a valid input");
        }

    }
}
