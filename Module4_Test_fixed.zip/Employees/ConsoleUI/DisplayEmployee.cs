﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeLibrary;

namespace ConsoleUI
{
    public static class DisplayEmployee
    {
        public static void DisplayEmployeeInfo(List<Employee> inputList)
        {
            foreach (var employe in inputList)
            {
                Console.WriteLine($"Employee - {employe.Name} Phone - {employe.PhoneNumber} Age - {employe.Age}");
            }
        }

        public static void DisplayAverageAge(List<Employee> inputList)
        {
            int age = 0;
            double average = 0.0;

            foreach (var employe in inputList)
            {
                age += employe.Age;
            }
            average = age / inputList.Count();


            Console.WriteLine(average);
        }
    }
}
