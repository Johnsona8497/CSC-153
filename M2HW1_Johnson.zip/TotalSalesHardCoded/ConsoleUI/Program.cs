﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleUI
{
    /**
    * 2/17/19
    * CSC 153
    * Anthony Johnson
    * Program that uses an array that has the following values loaded, (1245.67, 1189.55, 1098.72, 1456.88, 2109.34, 1987.55, 1872.36).
*/

    class Program
    {
        static void Main(string[] args)
        {
            double[] numbers = { 1245.67, 1189.55, 1098.72, 1456.88, 2109.34, 1987.55, 1872.36 };
            foreach (double number in numbers)
            {
                Console.WriteLine($"The Number: {number} ");

            }
            Console.ReadLine();
        }
    }
}
