﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLibrary
{
    public class Employee
    {
        // Fields
        private string _name;
        private string _phoneNumber;
        private int _age;
        private string _email;
        private int _pay;
        private string v;

        // Constructers
        public Employee()
        {
            Name = "No Name";
            PhoneNumber = "No Phone";
            Age = 0;
            Email = "No email";
            Pay = 9;

            
        }

        public Employee(string v, int pay)
        {
            this.v = v;
            Pay = pay;
        }

        public Employee(string name, string phone, int age, string email, int pay)
        {
            Name = name;
            PhoneNumber = phone;
            Age = age;
            Email = email;
            Pay = pay;
        }
        // Properties
        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
            }
        }

        public string PhoneNumber
        {
            get
            {
                return _phoneNumber;
            }
            set
            {
                _phoneNumber = value;
            }
        }

        public int Age
        {
            get
            {
                return _age;
            }
            set
            {
                _age = value;
            }
        }

        public string Email
        {
            get
            {
                return _email;
            }
            set
            {
                _email = value;
            }
        }

        public int Pay
        {
            get
            {
                return _pay;
            }
            set
            {
                _pay = value;
            }
        }

        // Methods
        public virtual string MakeEmail()
        {
            return Email + "@worker.com";
        }
    }
}
