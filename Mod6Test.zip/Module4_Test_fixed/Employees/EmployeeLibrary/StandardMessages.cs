﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLibrary
{    
    public static class StandardMessages
    {
        public static string DisplayMenu() 
        {
            return "1. Enter Employee's Information \n2. Display Employee's Information \n3. Display Average Employee Age \n4. Exit Program." +
                "\nPlease Enter a 1/2/3/4 ----> ";
        }

        public static string GetEmployeeName() 
        {
            return "Enter The Employee's Name ----> ";
        }

        public static string GetEmployeePhoneNum() 
        {
            return "Enter The Employee's Phone Number ----> ";
        }

        public static string GetEmployeeAge() 
        {
            return "Enter The Employee's Age ----> ";
        }

        public static string GetEmployeeEmail()
        {
            return "Enter The Empolyee's lastname ---->";
        }

        public static string DisplayGoodbye() 
        {
            return "Have a nice day";
        }

        public static string CleaningCode() 
        {
            return " ";
        }

        public static string DisplayMenuError()
        {
            return "Error! Not a valid menu choice!";
        }

        public static string DisplayAgeError()
        {
            return "Must be 16 or older, please re-enter";
        }

    }
}
