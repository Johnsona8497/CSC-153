﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLibrary
{
    public class Manager :  Employee
    {
        private int _pay;
        public Manager(int pay) : base("Manager", pay)
        {

        }

        public int pay
        {
            get { return _pay; }
            set { _pay = value; }
        }

        public override string MakeEmail()
        {
            return Email + "@manager.com";
        }
    }
}
