﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeLibrary;

namespace ConsoleUI
{
    public class BuildEmployee
    {
        public static void BuildAEmployee(List<Employee> inputList)
        {
            bool correct = false;

            Employee output = new Employee();

            Console.WriteLine(StandardMessages.GetEmployeeName());
            output.Name = Console.ReadLine();

            Console.WriteLine(StandardMessages.GetEmployeePhoneNum());
            output.PhoneNumber = Console.ReadLine();

            do
            {
                Console.WriteLine(StandardMessages.GetEmployeeAge());
                output.Age = TryParse.ParseToInt(Console.ReadLine());

                if (output.Age >= 16)
                {
                    correct = true;
                }
                else
                {
                    Console.WriteLine(StandardMessages.DisplayAgeError());
                }

            } while (correct == false);

            Console.WriteLine(StandardMessages.GetEmployeeEmail());
            output = Employee.MakeEmail();
            // I can't figure out why this is giving my an error.


            inputList.Add(output);
            
        }


        
    }
}
