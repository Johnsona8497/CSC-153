﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mod_3_Test
{
    class MainProgram
    {
        static void Main(string[] args)
        {
            {
                //create input var for user input and sentury for loop             
                string input;
                //create constant var 
                const int SIZE = 5;

                int nameIndex = 0, phoneIndex = 0;


                string[] employeeName = new string[SIZE]; string[] employeePhone = new string[SIZE];
                List<int> employeeAge = new List<int>();
                void Menu()
                {
                    
                    Console.WriteLine(EmployeeLibrary.StandardMessages.DisplayMenu());
                    input = Console.ReadLine();
                    Choices();
  
                }

                
                void Choices()
                {
                    if (input == "1")
                    {
                        EmployeeNames(ref employeeName, ref nameIndex, input);
                        Menu();
                    }

                    else if (input == "2")
                    {
                        EnterPhone(ref employeePhone, ref phoneIndex, input);
                        Menu();
                    }

                    else if (input == "3")
                    {
                        EnterAge(employeeAge, input);
                        Menu();
                    }
                    else if (input == "4")
                    {
                        DisplayEmpInfoToUser(employeeName, employeePhone, employeeAge);
                        Menu();
                    }
                    else if (input == "5")
                    {
                        Console.WriteLine(employeeAge.Average());
                        Console.WriteLine();
                        Menu();
                    }
                    else if (input == "6")
                    {
                      
                    }
                    else
                    {
                        Console.WriteLine(EmployeeLibrary.StandardMessages.DisplayNumberError());

                    }

                    }




                Menu();

            }
        }

        public static void EmployeeNames(ref string[] name, ref int index, string input) 
        {
            Console.WriteLine(EmployeeLibrary.StandardMessages.PromptForName());
            input = Console.ReadLine(); name[index] = input; index++;
            Console.WriteLine();
        }

        public static void EnterPhone(ref string[] phone, ref int index, string input)
        {
            Console.WriteLine(EmployeeLibrary.StandardMessages.PromptForNumber());
            input = Console.ReadLine(); phone[index] = input;
            index++; Console.WriteLine();
        }

        public static List<int> EnterAge(List<int> empAge, string input)
        {
            int number = 0;
            Console.WriteLine(EmployeeLibrary.StandardMessages.PromptForAge());
            input = Console.ReadLine();

            List<int> age = new List<int>();
            age = empAge;


            if (int.TryParse(input, out number))
            {
                age.Add(number);
            }
            else
            {
                Console.WriteLine(EmployeeLibrary.StandardMessages.DisplayNumberError());
            }
            Console.WriteLine();

            return age;

        }
        public static void DisplayEmpInfoToUser(string[] name, string[] phone, List<int> age)
        {
            for (int index = 0; index < age.Count; index++)
            {
                Console.WriteLine(EmployeeLibrary.StandardMessages.DisplayEmployee(name, phone, age, index));

            }
            Console.WriteLine();
        }
    }
}
