﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EmployeeLibrary
{
    public static class StandardMessages
    {
        public static string  DisplayMenu()
        {
            return " 1. Enter employee's name \n 2. Enter employee's phone number \n 3. Enter employee's age \n 4. Display employee information \n 5. Display average age of employees \n 6. Exit";
        }
        public static string PromptForName()
        {
            return "Enter empolyee's name -->";
        }

        public static string PromptForNumber()
        {
            return "Enter empolyee's phone number -->";
        }

        public static string PromptForAge()
        {
            return "Enter empolyee's age -->";
        }
        public static string DisplayNumberError()
        {
            return "Not a Valid Numnber!";
        }

        public static string DisplayEmployee(string[] name, string[] phone, List<int> age, int index)
        {
            return $"Employee Name- {name[index]}\n" + $"Employee Phone- {phone[index]}\n" + $"Employee Age- {age[index]}";
        }

    }
}
