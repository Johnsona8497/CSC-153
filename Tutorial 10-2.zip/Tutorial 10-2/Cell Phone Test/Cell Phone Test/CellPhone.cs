﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cell_Phone_Test
{
    class CellPhone
    {
        // Constructor
        public CellPhone()
        {
            Brand = "";
            Model = "";
            Price = 0m;
        }

        // Brand property
        public string Brand { get; set; }

        // Model property
        public string Model { get; set; }

        // Price property
        public decimal Price { get; set; }
    }
}
