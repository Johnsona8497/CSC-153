﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employees
{
    class Program
    {

        static void Main(string[] args)
        {



            string name;
            int age;
            float pnumber;
            int choice;
            name = "null";
            age = 0;
            pnumber = 0;



            menu();

            //Console.WriteLine("Please select a choice from the following options: ");
            //Console.WriteLine("1. Enter an Empolyee's name");
            //Console.WriteLine("2. Enter an Empolyee's phone number");
            //Console.WriteLine("3. Enter an empolee's age");
            //Console.WriteLine("4. Display an employee's information");
            //Console.WriteLine("5. Display the average age of all empolyees");
            //choice = int.Parse(Console.ReadLine());




            void menu()
            {
                Console.WriteLine("Please select a choice from the following options: ");
                Console.WriteLine("1. Enter an Empolyee's name");
                Console.WriteLine("2. Enter an Empolyee's phone number");
                Console.WriteLine("3. Enter an empolee's age");
                Console.WriteLine("4. Display an employee's information");
                Console.WriteLine("5. Display the average age of all empolyees");
                choice = int.Parse(Console.ReadLine());
                options();
            }

            void options()
            {
                if (choice == 1)
                {
                    Console.WriteLine("What is the empolyee's name?: ");
                    name = (Console.ReadLine());
                    Console.WriteLine("The Employees name is: ");
                    Console.Write(name);
                    Console.WriteLine();
                    Console.WriteLine();
                    menu();
                }

                else if (choice == 2)
                {
                    Console.WriteLine("What is the empolyee's number(Without dashes ex 9104531234?): ");
                    pnumber = float.Parse(Console.ReadLine());
                    Console.WriteLine("The Employees number is:");
                    Console.Write(pnumber);
                    Console.WriteLine();
                    Console.WriteLine();
                    menu();
                }

                else if (choice == 3)
                {
                    Console.WriteLine("How old is the empolyee?: ");
                    age = int.Parse(Console.ReadLine());
                    Console.WriteLine("The Employees age is:", age);
                    Console.Write(age);
                    Console.WriteLine();
                    Console.WriteLine();
                    menu();
                }

                else if (choice == 4)
                {
                    if (name == "null")
                    {
                        Console.WriteLine("Please return to the menu and enter an employyees name");
                        menu();
                    }
                    else if (age == 0)
                    {
                        Console.WriteLine("Please return to the menu and enter an employyees age");
                        menu();
                    }
                    else if (pnumber == 0)
                    {
                        Console.WriteLine("Please return to the menu and enter an employyees phone number");
                        menu();
                    }
                    else
                    {
                        Console.WriteLine();
                        Console.WriteLine("The Employees name is: ");
                        Console.Write(name);
                        Console.WriteLine();
                        Console.WriteLine("The Employees age is: ");
                        Console.Write(age);
                        Console.WriteLine();
                        Console.WriteLine("The Employees number is:");
                        Console.Write(pnumber);
                        Console.WriteLine();

                        menu();

                    }


                }

                else if (choice == 5)
                {
                    Console.WriteLine("PlaceHolder");
                }

                else
                {
                    Console.WriteLine("Invalid choice, Please select a choice from the following options: ");
                    Console.WriteLine("1. Enter an Empolyee's name");
                    Console.WriteLine("2. Enter an Empolyee's phone number");
                    Console.WriteLine("3. Enter an empolee's age");
                    Console.WriteLine("4. Display an employee's information");
                    Console.WriteLine("5. Display the average age of all empolyees");
                    choice = int.Parse(Console.ReadLine());
                }
            }






            //const int SIZE = 3;
            //string name;
            //int age;
            //float number;
            //Console.WriteLine("What is the empolyee's name?: ");
            //name = (Console.ReadLine());
            //Console.WriteLine("How old is the empolyee?: ");
            //age = int.Parse(Console.ReadLine());
            //Console.WriteLine("What is the empolyee's number(Without dashes ex 9104531234?): ");
            //number = float.Parse(Console.ReadLine());

            //Console.WriteLine("The Employees name is: ");
            //Console.Write(name);
            //Console.WriteLine();
            //Console.WriteLine("The Employees age is:", age);
            //Console.Write(age);
            //Console.WriteLine();
            //Console.WriteLine("The Employees number is:");
            //Console.Write(number);
            //Console.WriteLine();




            Console.ReadLine();
        }

    }
}
