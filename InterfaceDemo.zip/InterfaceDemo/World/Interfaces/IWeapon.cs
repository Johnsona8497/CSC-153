﻿namespace World
{
    public interface IWeapon
    {
        string DamageType { get; set; }
        string Description { get; set; }
        string Name { get; set; }

        void DisplayError();
    }
}