﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace World
{
    public class Player
    {
        // Fields
        private string _firstName;
        private string _lastName;

        // Constructers
        // Default
        public Player()
        {
            FirstName = "";
            LastName = "";
            Health = 0;
            List<IInventoryItem> inventory = new List<IInventoryItem>();
        }

        // Custom
        public Player(string firstName, string lastName, int health)
        {
            FirstName = firstName;
            LastName = lastName;
            Health = health;
        }


        // Full Properties
        public string FirstName
        {
            get
            {
                return _firstName;
            }
            set
            {
                _firstName = value;
            }
        }

        public string LastName
        {
            get
            {
                return _lastName;
            }
            set
            {
                _lastName = value;
            }
        }

        // Auto Property
        // No Backing Fields
        public int Health { get; set; }
    }
}
