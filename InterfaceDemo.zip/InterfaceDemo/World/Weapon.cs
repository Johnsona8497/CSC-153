﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace World
{


    public class Weapon : IInventoryItem
    {
        private string _name;
        private string _damageType;
        private int _minDamage;
        private int _maxDamage;

        public Weapon()
        {
            Name = "";
            DamageType = "";
            MinDamage = 0;
            MaxDamage = 0;
        }

        public Weapon(string name, string damageType, int minDam, int maxDam)
        {
            Name = name;
            DamageType = damageType;
            MinDamage = minDam;
            MaxDamage = maxDam;
        }

        public Weapon(string name, int minDam, int maxDam)
        {
            Name = name;
            MinDamage = minDam;
            MaxDamage = maxDam;
        }


        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
            }
        }

        public string DamageType
        {
            get
            {
                return _damageType;
            }
            set
            {
                _damageType = value;
            }
        }

        public int MinDamage
        {
            get
            {
                return _minDamage;
            }
            set
            {
                _minDamage = value;
            }
        }

        public int MaxDamage
        {
            get
            {
                return _maxDamage;
            }
            set
            {
                _maxDamage = value;
            }
        }

        public string Description { get; set; }

        public void DisplayError()
        {
            Console.WriteLine("Place holder");
        }
    }
}
